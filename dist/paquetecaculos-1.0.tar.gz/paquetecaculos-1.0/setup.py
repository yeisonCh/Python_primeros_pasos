from setuptools import setup

setup(
    name="paquetecaculos",
    version="1.0",
    description="Paquete de calculos matematicos",
    author=" Andres",
    author_email="yeisonchaparro@yahoo.com",
    packages=["calculos", "calculos.basicos"]

)