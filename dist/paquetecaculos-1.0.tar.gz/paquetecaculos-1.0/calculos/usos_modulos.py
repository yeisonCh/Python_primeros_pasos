from calculos_generales import dividir

dividir(10,2)