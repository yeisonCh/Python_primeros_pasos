#par crear paquetes es necesario crear una carpeta y dentro de ella creamos un archivo __init__.py



def potencia(base,exponente):
    print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
    print("El numero ", numero , "redondeado es : ", round(numero))